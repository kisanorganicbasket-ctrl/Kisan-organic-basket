पाठ 6 - Shopping Cart Demo
1. ZIP को Extract/Unzip करें।
2. index.html पर टैप करें और Chrome चुनें।
3. + और - दबाकर सामान की मात्रा बदलें।
4. Cart में सामान और कुल रकम देखें।

GitHub अपडेट: Repository > Add file > Upload files > Extract की हुई index.html चुनें > Commit changes.
यह केवल Demo है। वास्तविक ऑर्डर, OTP, भुगतान और डेटाबेस अभी नहीं जुड़े हैं। कीमतें अभ्यास के लिए हैं।
